const { EmbedBuilder } = require('discord.js');
const config = require('../config.json');

function formatMoney(amount) {
  return `${config.currency}${Number(amount).toLocaleString('en-US')}`;
}

function baseEmbed(color) {
  return new EmbedBuilder()
    .setColor(color || config.embedColor)
    .setFooter({ text: config.footerText })
    .setTimestamp();
}

function successEmbed(title, description) {
  return baseEmbed(config.successColor).setTitle(`✅ ${title}`).setDescription(description);
}

function errorEmbed(title, description) {
  return baseEmbed(config.errorColor).setTitle(`❌ ${title}`).setDescription(description);
}

function infoEmbed(title, description) {
  return baseEmbed(config.embedColor).setTitle(title).setDescription(description);
}

async function sendLog(client, embed) {
  if (!config.logChannelId) return;
  try {
    const channel = await client.channels.fetch(config.logChannelId);
    if (channel) channel.send({ embeds: [embed] });
  } catch (err) {}
}

module.exports = { formatMoney, baseEmbed, successEmbed, errorEmbed, infoEmbed, sendLog };
