const fs = require('fs');
const path = require('path');
const config = require('../config.json');

const DB_PATH = path.join(__dirname, '..', 'data', 'users.json');

function loadDB() {
  try {
    const raw = fs.readFileSync(DB_PATH, 'utf8');
    return JSON.parse(raw || '{}');
  } catch (err) {
    return {};
  }
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
}

function getUser(userId) {
  const db = loadDB();
  if (!db[userId]) {
    db[userId] = {
      cash: config.startingCash,
      bank: config.startingBank,
      debt: 0,
      lastWithdrawDate: null,
      withdrawnToday: 0,
      createdAt: new Date().toISOString(),
    };
    saveDB(db);
  }
  return db[userId];
}

function updateUser(userId, updates) {
  const db = loadDB();
  const user = db[userId] || getUser(userId);
  db[userId] = { ...user, ...updates };
  saveDB(db);
  return db[userId];
}

function getAllUsers() {
  return loadDB();
}

function resetDailyIfNeeded(userId) {
  const user = getUser(userId);
  const today = new Date().toISOString().slice(0, 10);
  if (user.lastWithdrawDate !== today) {
    updateUser(userId, { lastWithdrawDate: today, withdrawnToday: 0 });
    return getUser(userId);
  }
  return user;
}

module.exports = { loadDB, saveDB, getUser, updateUser, getAllUsers, resetDailyIfNeeded };
