const { Events } = require('discord.js');
const config = require('../config.json');
const db = require('../utils/database');
const { infoEmbed, errorEmbed, formatMoney } = require('../utils/embed');

const prefixCommands = {
  balance: async (msg) => {
    const user = db.getUser(msg.author.id);
    const total = user.cash + user.bank - user.debt;
    return msg.reply({
      embeds: [
        infoEmbed(
          `💳 رصيد ${msg.author.username}`,
          `**كاش 💵:** ${formatMoney(user.cash)}\n**بنك 🏦:** ${formatMoney(user.bank)}\n**ديون 💸:** ${formatMoney(user.debt)}\n\n**المجموع الصافي:** ${formatMoney(total)}`
        ),
      ],
    });
  },
  help: async (msg) => {
    return msg.reply({
      embeds: [
        infoEmbed(
          `📖 ${config.botName}`,
          `استخدم Slash Commands \`/help\` لعرض جميع الأوامر.\nأو البريفكس: \`${config.prefix}balance\``
        ),
      ],
    });
  },
};

module.exports = {
  name: Events.MessageCreate,
  async execute(message) {
    if (message.author.bot) return;
    if (!message.content.startsWith(config.prefix)) return;
    const args = message.content.slice(config.prefix.length).trim().split(/ +/);
    const commandName = args.shift().toLowerCase();
    const handler = prefixCommands[commandName];
    if (!handler) return;
    try {
      await handler(message, args);
    } catch (err) {
      console.error(err);
      message.reply({ embeds: [errorEmbed('خطأ', 'صار خطأ. جرب مرة ثانية.')] }).catch(() => {});
    }
  },
};
