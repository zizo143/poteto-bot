const { Events, ActivityType } = require('discord.js');
const config = require('../config.json');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ تم تسجيل الدخول باسم ${client.user.tag}`);
    client.user.setPresence({
      activities: [{ name: config.botName, type: ActivityType.Watching }],
      status: 'online',
    });
  },
};
