const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../utils/database');
const config = require('../config.json');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

function isAdmin(member) {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (config.adminRoleId && member.roles.cache.has(config.adminRoleId)) return true;
  return false;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin-remove')
    .setDescription('[إداري] خصم فلوس من شخص')
    .addUserOption(opt => opt.setName('user').setDescription('الشخص').setRequired(true))
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1))
    .addStringOption(opt => opt.setName('type').setDescription('كاش أو بنك').setRequired(true)
      .addChoices({ name: 'كاش', value: 'cash' }, { name: 'بنك', value: 'bank' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('ممنوع', 'ما عندك صلاحية.')], ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const type = interaction.options.getString('type');
    const user = db.getUser(target.id);
    const current = type === 'cash' ? user.cash : user.bank;
    const newValue = Math.max(0, current - amount);
    const updates = type === 'cash' ? { cash: newValue } : { bank: newValue };
    db.updateUser(target.id, updates);
    const embed = successEmbed('تم الخصم',
      `تم خصم **${formatMoney(amount)}** من ${type === 'cash' ? '💵 كاش' : '🏦 بنك'} ${target}.`);
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`⚙️ خصم إداري - بواسطة ${interaction.user.tag}`));
  },
};
