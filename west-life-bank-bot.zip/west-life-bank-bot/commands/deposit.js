const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('deposit')
    .setDescription('إيداع فلوس من الكاش إلى البنك')
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const user = db.getUser(interaction.user.id);
    if (amount > user.cash) {
      return interaction.reply({
        embeds: [errorEmbed('رصيد الكاش غير كافي', `عندك فقط ${formatMoney(user.cash)} كاش.`)],
        ephemeral: true,
      });
    }
    db.updateUser(interaction.user.id, { cash: user.cash - amount, bank: user.bank + amount });
    const embed = successEmbed(
      'تم الإيداع بنجاح',
      `تم إيداع **${formatMoney(amount)}** في حسابك البنكي.\n\n💵 كاش: ${formatMoney(user.cash - amount)}\n🏦 بنك: ${formatMoney(user.bank + amount)}`
    );
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`📥 إيداع - ${interaction.user.tag}`));
  },
};
