const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('transfer')
    .setDescription('تحويل فلوس من بنكك إلى بنك شخص ثاني')
    .addUserOption(opt => opt.setName('user').setDescription('المستلم').setRequired(true))
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    if (target.bot) return interaction.reply({ embeds: [errorEmbed('غير مسموح', 'ما تقدر تحول للبوتات.')], ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed('غير مسموح', 'ما تقدر تحول لنفسك.')], ephemeral: true });
    const sender = db.getUser(interaction.user.id);
    const receiver = db.getUser(target.id);
    if (amount > sender.bank) {
      return interaction.reply({
        embeds: [errorEmbed('رصيد البنك غير كافي', `عندك فقط ${formatMoney(sender.bank)} في البنك.`)],
        ephemeral: true,
      });
    }
    db.updateUser(interaction.user.id, { bank: sender.bank - amount });
    db.updateUser(target.id, { bank: receiver.bank + amount });
    const embed = successEmbed('تم التحويل بنجاح',
      `تم تحويل **${formatMoney(amount)}** إلى ${target}.\n\n🏦 رصيد بنكك الحالي: ${formatMoney(sender.bank - amount)}`);
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`🔁 تحويل - ${interaction.user.tag} ← ${target.tag}`));
  },
};
