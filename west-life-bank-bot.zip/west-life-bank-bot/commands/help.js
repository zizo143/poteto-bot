const { SlashCommandBuilder } = require('discord.js');
const { infoEmbed } = require('../utils/embed');
const config = require('../config.json');

module.exports = {
  data: new SlashCommandBuilder().setName('help').setDescription('عرض جميع أوامر البنك'),
  async execute(interaction) {
    const desc = [
      '**💳 أوامر الأعضاء:**',
      '`/balance` — عرض رصيدك',
      '`/deposit <مبلغ>` — إيداع في البنك',
      '`/withdraw <مبلغ>` — سحب من البنك',
      '`/transfer <عضو> <مبلغ>` — تحويل بنكي',
      '`/pay <عضو> <مبلغ>` — دفع كاش',
      '`/loan <مبلغ>` — أخذ قرض',
      '`/repay <مبلغ>` — سداد القرض',
      '`/leaderboard` — لوحة الأغنياء',
      '',
      '**⚙️ أوامر الإدارة:**',
      '`/admin-add <عضو> <مبلغ> <نوع>` — إضافة فلوس',
      '`/admin-remove <عضو> <مبلغ> <نوع>` — خصم فلوس',
      '',
      `📌 يمكن استخدام البريفكس \`${config.prefix}\``,
    ].join('\n');
    const embed = infoEmbed(`📖 ${config.botName} — قائمة الأوامر`, desc);
    await interaction.reply({ embeds: [embed] });
  },
};
