const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const db = require('../utils/database');
const config = require('../config.json');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

function isAdmin(member) {
  if (member.permissions.has(PermissionFlagsBits.Administrator)) return true;
  if (config.adminRoleId && member.roles.cache.has(config.adminRoleId)) return true;
  return false;
}

module.exports = {
  data: new SlashCommandBuilder()
    .setName('admin-add')
    .setDescription('[إداري] إضافة فلوس لشخص')
    .addUserOption(opt => opt.setName('user').setDescription('الشخص').setRequired(true))
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1))
    .addStringOption(opt => opt.setName('type').setDescription('كاش أو بنك').setRequired(true)
      .addChoices({ name: 'كاش', value: 'cash' }, { name: 'بنك', value: 'bank' }))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  async execute(interaction) {
    if (!isAdmin(interaction.member)) {
      return interaction.reply({ embeds: [errorEmbed('ممنوع', 'ما عندك صلاحية.')], ephemeral: true });
    }
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    const type = interaction.options.getString('type');
    const user = db.getUser(target.id);
    const updates = type === 'cash' ? { cash: user.cash + amount } : { bank: user.bank + amount };
    db.updateUser(target.id, updates);
    const embed = successEmbed('تمت الإضافة',
      `تم إضافة **${formatMoney(amount)}** إلى ${type === 'cash' ? '💵 كاش' : '🏦 بنك'} ${target}.`);
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`⚙️ إضافة إدارية - بواسطة ${interaction.user.tag}`));
  },
};
