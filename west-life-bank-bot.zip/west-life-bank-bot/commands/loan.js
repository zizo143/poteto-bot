const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const config = require('../config.json');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('loan')
    .setDescription('أخذ قرض من البنك (فائدة 10%)')
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const user = db.getUser(interaction.user.id);
    if (user.debt > 0) {
      return interaction.reply({
        embeds: [errorEmbed('عليك دين سابق',
          `لازم تسدد دينك أولاً: ${formatMoney(user.debt)}\nاستخدم \`/repay\``)],
        ephemeral: true,
      });
    }
    if (amount > config.loanMaxAmount) {
      return interaction.reply({
        embeds: [errorEmbed('المبلغ يتجاوز الحد المسموح',
          `الحد الأقصى للقرض: ${formatMoney(config.loanMaxAmount)}`)],
        ephemeral: true,
      });
    }
    const debtWithInterest = Math.floor(amount * (1 + config.loanInterest));
    db.updateUser(interaction.user.id, { cash: user.cash + amount, debt: debtWithInterest });
    const embed = successEmbed('تم صرف القرض',
      `تم إضافة **${formatMoney(amount)}** إلى كاشك.\nالفائدة: ${(config.loanInterest * 100).toFixed(0)}%\n**المطلوب سداده:** ${formatMoney(debtWithInterest)}`);
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`🏦 قرض - ${interaction.user.tag}`));
  },
};
