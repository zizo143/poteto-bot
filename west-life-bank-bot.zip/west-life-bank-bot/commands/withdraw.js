const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const config = require('../config.json');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('withdraw')
    .setDescription('سحب فلوس من البنك إلى الكاش')
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    let user = db.resetDailyIfNeeded(interaction.user.id);
    if (amount > user.bank) {
      return interaction.reply({
        embeds: [errorEmbed('رصيد البنك غير كافي', `عندك فقط ${formatMoney(user.bank)} في البنك.`)],
        ephemeral: true,
      });
    }
    if (user.withdrawnToday + amount > config.dailyWithdrawLimit) {
      const remaining = config.dailyWithdrawLimit - user.withdrawnToday;
      return interaction.reply({
        embeds: [errorEmbed('تجاوزت الحد اليومي للسحب',
          `الحد اليومي: ${formatMoney(config.dailyWithdrawLimit)}\nتبقى لك اليوم: ${formatMoney(remaining)}`)],
        ephemeral: true,
      });
    }
    db.updateUser(interaction.user.id, {
      cash: user.cash + amount,
      bank: user.bank - amount,
      withdrawnToday: user.withdrawnToday + amount,
    });
    const embed = successEmbed(
      'تم السحب بنجاح',
      `تم سحب **${formatMoney(amount)}** من حسابك البنكي.\n\n💵 كاش: ${formatMoney(user.cash + amount)}\n🏦 بنك: ${formatMoney(user.bank - amount)}`
    );
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`📤 سحب - ${interaction.user.tag}`));
  },
};
