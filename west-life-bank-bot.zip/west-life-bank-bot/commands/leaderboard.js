const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { infoEmbed, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('leaderboard')
    .setDescription('لوحة أغنى الأعضاء في السيرفر'),
  async execute(interaction) {
    const users = db.getAllUsers();
    const sorted = Object.entries(users)
      .map(([id, data]) => ({ id, total: (data.cash || 0) + (data.bank || 0) - (data.debt || 0) }))
      .sort((a, b) => b.total - a.total)
      .slice(0, 10);
    if (sorted.length === 0) {
      return interaction.reply({ embeds: [infoEmbed('🏆 لوحة الأغنياء', 'لا يوجد بيانات بعد.')] });
    }
    const medals = ['🥇', '🥈', '🥉'];
    const lines = await Promise.all(
      sorted.map(async (entry, i) => {
        const rank = medals[i] || `**${i + 1}.**`;
        let name = `<@${entry.id}>`;
        try { const u = await interaction.client.users.fetch(entry.id); name = u.username; } catch (e) {}
        return `${rank} **${name}** — ${formatMoney(entry.total)}`;
      })
    );
    const embed = infoEmbed('🏆 أغنى 10 أعضاء | West Life', lines.join('\n'));
    await interaction.reply({ embeds: [embed] });
  },
};
