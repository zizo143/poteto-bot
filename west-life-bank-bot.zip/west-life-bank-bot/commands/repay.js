const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('repay')
    .setDescription('سداد القرض (من الكاش أو البنك)')
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1))
    .addStringOption(opt => opt.setName('source').setDescription('من وين تسدد؟').setRequired(false)
      .addChoices({ name: 'من الكاش', value: 'cash' }, { name: 'من البنك', value: 'bank' })),
  async execute(interaction) {
    const amount = interaction.options.getInteger('amount');
    const source = interaction.options.getString('source') || 'cash';
    const user = db.getUser(interaction.user.id);
    if (user.debt <= 0) {
      return interaction.reply({ embeds: [errorEmbed('لا يوجد دين', 'ما عليك أي دين حالياً.')], ephemeral: true });
    }
    const payAmount = Math.min(amount, user.debt);
    if (source === 'cash') {
      if (user.cash < payAmount) {
        return interaction.reply({ embeds: [errorEmbed('كاش غير كافي', `عندك ${formatMoney(user.cash)} كاش فقط.`)], ephemeral: true });
      }
      db.updateUser(interaction.user.id, { cash: user.cash - payAmount, debt: user.debt - payAmount });
    } else {
      if (user.bank < payAmount) {
        return interaction.reply({ embeds: [errorEmbed('رصيد البنك غير كافي', `عندك ${formatMoney(user.bank)} فقط.`)], ephemeral: true });
      }
      db.updateUser(interaction.user.id, { bank: user.bank - payAmount, debt: user.debt - payAmount });
    }
    const remaining = user.debt - payAmount;
    const embed = successEmbed('تم السداد',
      `تم سداد **${formatMoney(payAmount)}** من دينك.\n**المتبقي:** ${formatMoney(remaining)}`);
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`💳 سداد قرض - ${interaction.user.tag}`));
  },
};
