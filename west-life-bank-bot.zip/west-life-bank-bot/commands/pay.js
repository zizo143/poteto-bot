const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { successEmbed, errorEmbed, sendLog, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('pay')
    .setDescription('دفع كاش (يد بيد) لشخص ثاني')
    .addUserOption(opt => opt.setName('user').setDescription('المستلم').setRequired(true))
    .addIntegerOption(opt => opt.setName('amount').setDescription('المبلغ').setRequired(true).setMinValue(1)),
  async execute(interaction) {
    const target = interaction.options.getUser('user');
    const amount = interaction.options.getInteger('amount');
    if (target.bot) return interaction.reply({ embeds: [errorEmbed('غير مسموح', 'ما تقدر تدفع للبوتات.')], ephemeral: true });
    if (target.id === interaction.user.id) return interaction.reply({ embeds: [errorEmbed('غير مسموح', 'ما تقدر تدفع لنفسك.')], ephemeral: true });
    const sender = db.getUser(interaction.user.id);
    const receiver = db.getUser(target.id);
    if (amount > sender.cash) {
      return interaction.reply({
        embeds: [errorEmbed('رصيد الكاش غير كافي', `عندك فقط ${formatMoney(sender.cash)} كاش.`)],
        ephemeral: true,
      });
    }
    db.updateUser(interaction.user.id, { cash: sender.cash - amount });
    db.updateUser(target.id, { cash: receiver.cash + amount });
    const embed = successEmbed('تم الدفع بنجاح',
      `تم دفع **${formatMoney(amount)}** كاش إلى ${target}.\n\n💵 كاشك الحالي: ${formatMoney(sender.cash - amount)}`);
    await interaction.reply({ embeds: [embed] });
    sendLog(interaction.client, embed.setTitle(`💵 دفع - ${interaction.user.tag} ← ${target.tag}`));
  },
};
