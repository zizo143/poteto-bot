const { SlashCommandBuilder } = require('discord.js');
const db = require('../utils/database');
const { infoEmbed, formatMoney } = require('../utils/embed');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('balance')
    .setDescription('عرض رصيدك في البنك (كاش، بنك، ديون)')
    .addUserOption(opt => opt.setName('user').setDescription('عرض رصيد شخص آخر').setRequired(false)),
  async execute(interaction) {
    const target = interaction.options.getUser('user') || interaction.user;
    const user = db.getUser(target.id);
    const total = user.cash + user.bank - user.debt;
    const embed = infoEmbed(
      `💳 رصيد ${target.username}`,
      `**كاش 💵:** ${formatMoney(user.cash)}\n**بنك 🏦:** ${formatMoney(user.bank)}\n**ديون 💸:** ${formatMoney(user.debt)}\n\n**المجموع الصافي:** ${formatMoney(total)}`
    ).setThumbnail(target.displayAvatarURL({ dynamic: true }));
    await interaction.reply({ embeds: [embed] });
  },
};
